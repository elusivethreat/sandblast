# Copyright (C) 2020 FireEye, Inc. All Rights Reserved.
from speakeasy.cli import main

main()
